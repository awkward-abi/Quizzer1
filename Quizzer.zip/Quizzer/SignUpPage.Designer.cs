﻿namespace Quizzer
{
    partial class SignUpPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUpPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtbxUserN = new System.Windows.Forms.Label();
            this.txtbxuserN1 = new System.Windows.Forms.TextBox();
            this.rbtnteach = new System.Windows.Forms.RadioButton();
            this.rbtnstud = new System.Windows.Forms.RadioButton();
            this.txtbxPass1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbxLN = new System.Windows.Forms.TextBox();
            this.txtbxFN = new System.Windows.Forms.TextBox();
            this.btnLogIn1 = new System.Windows.Forms.Button();
            this.btnRegister1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Bisque;
            this.panel1.Controls.Add(this.txtbxUserN);
            this.panel1.Controls.Add(this.txtbxuserN1);
            this.panel1.Controls.Add(this.rbtnteach);
            this.panel1.Controls.Add(this.rbtnstud);
            this.panel1.Controls.Add(this.txtbxPass1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtbxLN);
            this.panel1.Controls.Add(this.txtbxFN);
            this.panel1.Location = new System.Drawing.Point(63, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 257);
            this.panel1.TabIndex = 9;
            // 
            // txtbxUserN
            // 
            this.txtbxUserN.AutoSize = true;
            this.txtbxUserN.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtbxUserN.Location = new System.Drawing.Point(26, 152);
            this.txtbxUserN.Name = "txtbxUserN";
            this.txtbxUserN.Size = new System.Drawing.Size(99, 34);
            this.txtbxUserN.TabIndex = 16;
            this.txtbxUserN.Text = "USERNAME";
            // 
            // txtbxuserN1
            // 
            this.txtbxuserN1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtbxuserN1.Location = new System.Drawing.Point(169, 154);
            this.txtbxuserN1.Name = "txtbxuserN1";
            this.txtbxuserN1.Size = new System.Drawing.Size(225, 25);
            this.txtbxuserN1.TabIndex = 15;
            // 
            // rbtnteach
            // 
            this.rbtnteach.AutoSize = true;
            this.rbtnteach.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbtnteach.Location = new System.Drawing.Point(169, 26);
            this.rbtnteach.Name = "rbtnteach";
            this.rbtnteach.Size = new System.Drawing.Size(113, 38);
            this.rbtnteach.TabIndex = 14;
            this.rbtnteach.TabStop = true;
            this.rbtnteach.Text = "TEACHERS";
            this.rbtnteach.UseVisualStyleBackColor = true;
            // 
            // rbtnstud
            // 
            this.rbtnstud.AutoSize = true;
            this.rbtnstud.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rbtnstud.Location = new System.Drawing.Point(290, 26);
            this.rbtnstud.Name = "rbtnstud";
            this.rbtnstud.Size = new System.Drawing.Size(104, 38);
            this.rbtnstud.TabIndex = 13;
            this.rbtnstud.TabStop = true;
            this.rbtnstud.Text = "STUDENT";
            this.rbtnstud.UseVisualStyleBackColor = true;
            // 
            // txtbxPass1
            // 
            this.txtbxPass1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtbxPass1.Location = new System.Drawing.Point(169, 194);
            this.txtbxPass1.Name = "txtbxPass1";
            this.txtbxPass1.Size = new System.Drawing.Size(225, 25);
            this.txtbxPass1.TabIndex = 12;
            this.txtbxPass1.TextChanged += new System.EventHandler(this.txtbxPass1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(26, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 34);
            this.label2.TabIndex = 11;
            this.label2.Text = "LAST NAME";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(26, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 34);
            this.label5.TabIndex = 9;
            this.label5.Text = "PASSWORD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Javanese Text", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(26, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 34);
            this.label3.TabIndex = 8;
            this.label3.Text = "FIRST NAME";
            // 
            // txtbxLN
            // 
            this.txtbxLN.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtbxLN.Location = new System.Drawing.Point(169, 113);
            this.txtbxLN.Name = "txtbxLN";
            this.txtbxLN.Size = new System.Drawing.Size(225, 25);
            this.txtbxLN.TabIndex = 2;
            this.txtbxLN.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtbxFN
            // 
            this.txtbxFN.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtbxFN.Location = new System.Drawing.Point(169, 72);
            this.txtbxFN.Name = "txtbxFN";
            this.txtbxFN.Size = new System.Drawing.Size(225, 25);
            this.txtbxFN.TabIndex = 1;
            this.txtbxFN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnLogIn1
            // 
            this.btnLogIn1.BackColor = System.Drawing.Color.Transparent;
            this.btnLogIn1.Font = new System.Drawing.Font("Javanese Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLogIn1.Location = new System.Drawing.Point(524, 31);
            this.btnLogIn1.Name = "btnLogIn1";
            this.btnLogIn1.Size = new System.Drawing.Size(84, 31);
            this.btnLogIn1.TabIndex = 11;
            this.btnLogIn1.Text = "LOG IN";
            this.btnLogIn1.UseVisualStyleBackColor = false;
            this.btnLogIn1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRegister1
            // 
            this.btnRegister1.Font = new System.Drawing.Font("Javanese Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnRegister1.Location = new System.Drawing.Point(645, 29);
            this.btnRegister1.Name = "btnRegister1";
            this.btnRegister1.Size = new System.Drawing.Size(98, 33);
            this.btnRegister1.TabIndex = 12;
            this.btnRegister1.Text = "REGISTER";
            this.btnRegister1.UseVisualStyleBackColor = true;
            this.btnRegister1.Click += new System.EventHandler(this.btnSignup1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(100, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 80);
            this.label1.TabIndex = 10;
            this.label1.Text = "Q U I Z Z E R";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Javanese Text", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnexit.Location = new System.Drawing.Point(645, 359);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(84, 31);
            this.btnexit.TabIndex = 17;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // SignUpPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(763, 417);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnRegister1);
            this.Controls.Add(this.btnLogIn1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.MaximumSize = new System.Drawing.Size(779, 456);
            this.MinimizeBox = false;
            this.Name = "SignUpPage";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quizzer";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Panel panel1;
        private Label label5;
        private Label label3;
        private TextBox txtbxLN;
        private TextBox txtbxFN;
        private TextBox txtbxPass1;
        private Label label2;
        private Button btnLogIn1;
        private Button btnRegister1;
        private RadioButton rbtnteach;
        private RadioButton rbtnstud;
        private Label txtbxUserN;
        private TextBox txtbxuserN1;
        private Label label1;
        private Button btnexit;
    }
}